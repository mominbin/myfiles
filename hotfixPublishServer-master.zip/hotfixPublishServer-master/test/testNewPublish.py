from clazz.crawler.phare import phare
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import os
from clazz.services.publish import PublishStep
from clazz.services.publish import PublishUtils
from lxml import etree
import win32com.client
import time
from selenium.webdriver.common.keys import Keys


def test_broswer():
    message = {'defectId': 'QCCR1E149464 ', 'patchId': 'SM9.60.1025_P1_HF3_test', 'version': '9.60', 'md5': {},
               'info': {'type': 'SM', 'version': '9.60', 'patch': '1', 'hotfix_no': '3', 'build_no': '1025'}}
    ps = PublishStep(message)
    ps.main()


def test_normal():
    driver = webdriver.Firefox()
    driver.get("http://www.baidu.com")


def test_phare():
    index = 3
    message = phare.get_message(index)
    print(message)


def test_parse_release_no():
    message = {'defectId': 'QCCR1E149464 ', 'patchId': 'SM9.60.1025_P1_HF3_test', 'version': '9.60', 'md5': {},
               'info': {'type': 'SM', 'version': '9.60', 'patch': '1', 'hotfix_no': '3', 'build_no': '1025'}}
    version = PublishUtils.parse_release_version(message)
    print(version)


def test_real_path():
    ps = PublishStep({})
    files = ps.get_readme_files()
    for file in files:
        print(os.path.realpath(file))


def load_html():
    f = open('test.html', 'r')
    data = f.read()
    f.close()
    # soup = BeautifulSoup(data,"lxml") equals to html = etree.HTML(data)
    # soup.prettify() equals to etree.tostring(html)
    return data

def get_checkbox(beautifulData):
    html = etree.HTML(beautifulData)
    checkbox = html.xpath("//td[font='aix_unify.tar.Z']")[0].getparent().xpath(".//div[@class='hpe-checkbox']")[0]
    c_xpath = checkbox.getroottree().getpath(checkbox)
    print(c_xpath)
    pass


def test_modify():
    message = {'defectId': 'QCCR1E149464 ', 'patchId': 'SM9.60.1025_P1_HF3_test', 'version': '9.60', 'md5': {},
               'info': {'type': 'SM', 'version': '9.60', 'patch': '1', 'hotfix_no': '3', 'build_no': '1025'},
               'file_list': []}
    modify_url = "https://rdapps.swinfra.net/hotfix/#/hotfix/6025"
    ps = PublishStep(message)
    ps.set_driver(PublishUtils.get_driver('Firefox', True))
    ps.modify(modify_url)


def test_get_checkbox():
    get_checkbox(load_html())

def test_cal_tommow_time():
    from datetime import datetime
    from datetime import timedelta
    now = datetime.now()
    aDay = timedelta(days=7)
    now = now + aDay
    print(now.strftime('%m/%d/%Y'))


def test_window_pop_up_handle():
    message = {'defectId': 'QCCR1E149464 ', 'patchId': 'SM9.60.1025_P1_HF3_test', 'version': '9.60', 'md5': {},
               'info': {'type': 'SM', 'version': '9.60', 'patch': '1', 'hotfix_no': '3', 'build_no': '1025'},
               'file_list': []}
    modify_url = "https://rdapps.swinfra.net/hotfix/#/hotfix/6025"
    ps = PublishStep(message)
    ps.set_driver(PublishUtils.get_driver('Firefox', True))
    ps.login()

    shell = win32com.client.Dispatch("WScript.Shell")
    shell.Sendkeys("mmo@microfocus.com")
    time.sleep(1)
    shell.Sendkeys("{TAB}")
    time.sleep(1)
    shell.Sendkeys("Taurus.m1")
    time.sleep(1)
    shell.Sendkeys("{ENTER}")

# it is not working for Chrome
def test_window_pop_up_handle2():
    message = {'defectId': 'QCCR1E149464 ', 'patchId': 'SM9.60.1025_P1_HF3_test', 'version': '9.60', 'md5': {},
               'info': {'type': 'SM', 'version': '9.60', 'patch': '1', 'hotfix_no': '3', 'build_no': '1025'},
               'file_list': []}
    modify_url = "https://rdapps.swinfra.net/hotfix/#/hotfix/6025"
    ps = PublishStep(message)
    ps.set_driver(PublishUtils.get_driver('Firefox', True))
    ps.login()
    WebDriverWait(ps.driver, 10).until(EC.alert_is_present())
    ps.driver.switch_to.alert.send_keys("mmo@microfocus.com" + Keys.TAB + "Taurus.m1")
    time.sleep(3)
    ps.driver.switch_to.alert.accept()

def test_string():
    minor = "SM 9.61"
    text = "sm9.61"
    print(minor.lower().replace(" ", "")==text)
# test_broswer()
# test_modify()
# test_get_checkbox()
# test_cal_tommow_time()
# test_phare()
test_window_pop_up_handle2()
# test_string()