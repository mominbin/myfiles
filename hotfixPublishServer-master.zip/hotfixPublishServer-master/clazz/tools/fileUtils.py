from ftplib import FTP
import os
import sys
import getopt
import requests
import configparser
import contextlib
from clazz.fileSingleton import fileSingleton
from hotfixPublish.settings import CONF_DIR



class FTPUpload:
    @staticmethod
    def get_cf():
        cf = configparser.ConfigParser()
        cf.read(CONF_DIR)
        return cf

    @staticmethod
    def ftp_up(filename, handle, operate_folder="/patch_upload"):
        ftp = FTPUpload.open_ftp()
        buff_size = 1024#设置缓冲块大小
        file_handler = open(filename, 'rb')#以读模式在本地打开文件
        ftp.storbinary('STOR %s' % os.path.basename(filename), file_handler, buff_size, handle.handle)#上传文件
        ftp.set_debuglevel(2)
        file_handler.close()
        ftp.quit()

    @staticmethod
    def open_ftp(operate_folder="/patch_upload"):
        cf = FTPUpload.get_cf()
        ftp_server = cf.get("upload", "ftp_server")
        ftp = FTP()
        ftp.set_debuglevel(0)  # 打开调试级别2，显示详细信息;0为关闭调试信息
        ftp.connect(ftp_server, 21)  # 连接
        ftp.login('', '')  # 登录，如果匿名登录则用空串代替即可
        # print ftp.getwelcome()#显示ftp服务器欢迎信息
        ftp.cwd(operate_folder)  # 选择操作目录
        return ftp

    @staticmethod
    def list_ftp_server_files():
        ftp = FTPUpload.open_ftp()
        files = ftp.nlst()
        ftp.quit()
        return files

    @staticmethod
    def is_exist(file_name):
        files = FTPUpload.list_ftp_server_files()
        for file in files:
            if file == file_name:
                return True
        return False

    @staticmethod
    def ftp_upload(url):
        file = Download.get_store_file(url)
        total_size = os.path.getsize(file)
        upload_tracker = FtpUploadTracker(int(total_size), url)
        FTPUpload.ftp_up(file, upload_tracker)


class FtpUploadTracker:
    size_written = 0
    total_size = 0
    last_shown_percent = 0
    done = False
    url = ""

    def __init__(self, total_size, url):
        self.total_size = total_size
        self.url = url

    def get_load_info(self):
        self.size_written += 1024
        percent_complete = round((self.size_written / self.total_size) * 100)
        if self.last_shown_percent != percent_complete:
            self.last_shown_percent = percent_complete

        if self.size_written >= self.total_size:
            self.done = True
        uploader = {}
        uploader["uploaded"] = self.size_written
        uploader["total"] = self.total_size
        uploader["percent"] = percent_complete
        uploader["done"] = self.done
        return uploader

    def handle(self, block):
        uploader = self.get_load_info()
        fileSingleton.set_uploader("up_" + self.url, uploader)


class Download:
    @staticmethod
    def download(url, file_to_store):
        usr_agent = {
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
            'Accept-Encoding': 'none',
            'Accept-Language': 'en-US,en;q=0.8',
            'Connection': 'keep-alive',
            'Authorization': 'Basic bW1vOkFxdWFyaXVzLm1v'
        }
        r = requests.get(url, headers=usr_agent)
        with open(file_to_store, 'wb') as f:
            f.write(r.content)

    @staticmethod
    def get_store_file(url):
        cf = configparser.ConfigParser()
        cf.read(CONF_DIR)
        ftp_path = cf.get("patch_central", "ftp_files_path")
        url.rfind('/')
        return ftp_path + '\\' + url[url.rfind('/')+1:]

    def download_file(self, url):
        self.download(url, self.get_store_file(url))

    @staticmethod
    def download_with_schedule(url):
        file = Download.get_store_file(url)
        with contextlib.closing(requests.get(url, stream=True)) as response:
            chunk_size = 1024  # 单次请求最大值
            content_size = int(response.headers['content-length'])  # 内容体总大小
            progress = ProgressBar(file, total=content_size,
                                   unit="KB", chunk_size=chunk_size, run_status="downloading", fin_status="done")
            with open(file, "wb") as file:
                for data in response.iter_content(chunk_size=chunk_size):
                    file.write(data)
                    progress.refresh(count=len(data))
                    downloader = progress.get_load_info()
                    fileSingleton.set_downloader("down_" + url, downloader)


class ProgressBar(object):

    def __init__(self, title,
                 count=0.0,
                 run_status=None,
                 fin_status=None,
                 total=100.0,
                 unit='', sep='/',
                 chunk_size=1.0):
        super(ProgressBar, self).__init__()
        self.info = "【%s】%s %.2f %s %s %.2f %s"
        self.title = title
        self.total = total
        self.count = count
        self.chunk_size = chunk_size
        self.status = run_status or ""
        self.fin_status = fin_status or " " * len(self.status)
        self.unit = unit
        self.seq = sep

    def __get_info(self):
        # 【名称】状态 进度 单位 分割线 总数 单位
        _info = self.info % (self.title, self.status,
                             self.count/self.chunk_size, self.unit, self.seq, self.total/self.chunk_size, self.unit)
        return _info

    def refresh(self, count=1, status=None):
        self.count += count
        # if status is not None:
        self.status = status or self.status
        end_str = "\r"
        if self.count >= self.total:
            end_str = '\n'
            self.status = status or self.fin_status

    def get_load_info(self):
        downloader = {}
        downloader["downloaded"] = self.count/self.chunk_size
        downloader["total"] = self.total/self.chunk_size
        downloader["title"] = self.title
        downloader["unit"] = self.unit
        downloader["percent"] = str(round((self.count/self.total)*100, 2)) + "%"
        downloader["done"] = self.status == "done"
        return downloader


class Usage(Exception):
    def __init__(self,):
        msg = "python fileUtils.py -f fileName (upload the fileName to the ftp server!)"
        self.msg = msg


def main(argv=None):
    if argv is None:
        argv = sys.argv
    try:
        try:
            opts, args = getopt.getopt(argv[1:], "hf:", ["help"])
            for o, a in opts:
                if o == '-f':
                    FTPUpload.ftp_up(a)
                if o == '--help':
                    print(Usage().msg)
        except getopt.error as msg:
            raise Usage(msg)
        # more code, unchanged
    except Usage as err:
        print(err.msg, file=sys.stderr)
        print("for help use --help", file=sys.stderr)
        return 2


# if __name__ == "__main__":
#     sys.exit(main())



