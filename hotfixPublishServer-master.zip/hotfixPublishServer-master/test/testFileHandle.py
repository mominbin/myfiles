from fileHandle import FileHandle


def test_donwload_readme():
    data = {'type': 'SM', 'version': '9.52', 'patch': '2', 'hotfix_no': '11', 'build_no': '2046'}
    FileHandle(data).readme_download()

def test_donwload_readme_for_94():
    data = {'type': 'SM', 'version': '9.41', 'patch': '6', 'hotfix_no': '12', 'build_no': '6037'}
    FileHandle(data).readme_download()

test_donwload_readme_for_94()
# test_donwload_readme()