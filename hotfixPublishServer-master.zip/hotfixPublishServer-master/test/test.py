from selenium import webdriver
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from time import sleep
import configparser
from hotfixPublish.settings import CONF_DIR

main_page = "https://patch-central.corp.hpecorp.net/crypt-web/protected/viewProduct.do?productid=crypt:service_manager:"
driver = None
LOGIN_PAGE = 1
MAIN_PAGE = 2


def is_login_page():
    username_input = driver.find_elements_by_xpath('//*[@id="username"]')[0]
    return username_input.is_displayed()
    # return EC.presence_of_element_located((By.XPATH, "//*[@id='password']"))


def is_main_page():
    try:
        driver.find_elements_by_xpath("//form[@name='addForm']/input")[0]
        return True
    except Exception as e:
        print(e)
        return False


def wait_next_page(seconds):
    try:
        WebDriverWait(driver, seconds).until(EC.presence_of_element_located((By.XPATH, "//*[@id='password']")) or EC.presence_of_element_located((By.XPATH, "//form[@name='addForm']/input")))
    finally:
        if is_main_page():
            current_page = MAIN_PAGE
        elif is_login_page():
            current_page = LOGIN_PAGE
        return current_page


def input_account_info(username, password):
    username_input = driver.find_elements_by_xpath('//*[@id="username"]')[0]
    password_input = driver.find_elements_by_xpath('//*[@id="password"]')[0]
    username_input.send_keys(username)
    password_input.send_keys(password)


def main(page):
    driver.get(page)
    current_pge = wait_next_page(20)
    if current_pge == LOGIN_PAGE:
        input_account_info("mmo@hpe.com", "Pisces.mo")
        driver.find_elements_by_xpath("//*/input[@type='submit']")[0].click()


def config_page():
    driver.get("about:config")
    driver.find_elements_by_xpath('//*[@id="warningButton"]')[0].click()
    driver.find_elements_by_xpath('// *[ @ id = "textbox"]')[0].click()
    sleep(2)
    driver.switch_to.active_element.send_keys('security.enterprise_roots.enabled')
    sleep(1)
    option = driver.find_elements_by_xpath('// *[ @ id = "configTreeBody"]')[0]
    action_chains = ActionChains(driver)
    action_chains.move_to_element(option)
    action_chains.double_click()
    action_chains.perform()


def test_firefox():
    # Firefox uses it's profile
    # fp = webdriver.FirefoxProfile(r'C:\Users\mominb\AppData\Roaming\Mozilla\Firefox\Profiles\9e8li553.default')
    # driver = webdriver.Firefox(fp)

    # chrome_profile_dir=r"C:\Users\mominb\AppData\Local\Google\Chrome\User Data"
    # chrome_options = webdriver.ChromeOptions()
    # chrome_options.add_argument("user-data-dir=" + os.path.abspath(chrome_profile_dir))
    # driver = webdriver.Chrome(chrome_options=chrome_options)
    driver = webdriver.Firefox()
    driver.maximize_window()
    config_page()
    # main(main_page)


def test_get_domain_path():
    cf = configparser.ConfigParser()
    cf.read(CONF_DIR)
    print(cf.get("domain", "domain_svn"))


test_get_domain_path()