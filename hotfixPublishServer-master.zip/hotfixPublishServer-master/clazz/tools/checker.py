import time
import json
from clazz.tools.fileUtils import *
from clazz.crawler.phare import phare


class Checker:
    @staticmethod
    def has_file(file_name, files_in_ftp):
        has_file = False
        for file in files_in_ftp:
            if file == file_name:
                has_file = True
                break
        return has_file

    @staticmethod
    def short_file_check(file_list):
        short_list = []
        files_in_ftp = FTPUpload.list_ftp_server_files()
        for file in file_list:
            if Checker.has_file(file, files_in_ftp) is False:
                short_list.append(file)
        return short_list

    @staticmethod
    def preparation_check(index):
        file_list = phare.get_release_files_name(index)
        short_list = Checker.short_file_check(file_list)
        message = {}
        if len(short_list) == 0:
            message["prepared"] = True
        else:
            message["prepared"] = False
        message["list"] = short_list
        return message




