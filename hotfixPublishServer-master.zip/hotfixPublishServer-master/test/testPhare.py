from clazz.crawler.phare import phare

def test_get_release_url():
    url = phare.get_release_files_name(4)
    print(url)

test_get_release_url()