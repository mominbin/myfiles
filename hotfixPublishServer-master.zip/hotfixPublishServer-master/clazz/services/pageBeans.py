from clazz.tools.locateUtils import *
from pyquery import PyQuery
from datetime import datetime
from datetime import timedelta


class SMMainPage:
    def __init__(self, driver, message):
        self.driver = driver
        self.add_button = LocateUtils.wait_present(self.driver, "//*[@title='Add Hotfix']")
        self.html = self.driver.page_source
        self.target_item = self.driver.find_element(By.XPATH, '//div[text()="' + SMMainPage.reflect_origin_text(self.html, SMMainPage.parse_release_version(message)) + '"]')

    @staticmethod
    def parse_release_version(message):
        ver_no = message['info']['version']
        version = ""
        if float(ver_no) >= 9.52:
            version = "sm" + ver_no if message['info']['patch'] is '0' else "sm" + ver_no + "p" + message['info'][
                'patch']
        else:
            version = "sm" + ver_no
        return version

    @staticmethod
    def reflect_origin_text(html, version_minor):
        doc = PyQuery(html)
        LIs = doc('ul li')
        text = ""
        for li in LIs:
            text = PyQuery(li).text()
            if text.lower().replace(" ", "") == version_minor:
                break
        return text


class HotFixDataPage:
    def __init__(self, driver):
        self.driver = driver
        self.hot_fix_id_input = LocateUtils.wait_present(self.driver, "/html/body/div/div/div[3]/div[2]/div/div[3]/div/div/div/div/div[2]/div/div/table/tbody/tr[1]/td[2]/input")
        self.description_input = self.driver.find_element_by_xpath("//input[@name='short_description']")
        self.crs_input = self.driver.find_element_by_xpath("/html/body/div/div/div[3]/div[2]/div/div[3]/div/div/div/div/div[2]/div/div/table/tbody/tr[3]/td[2]/input")
        self.expire_date_input = self.driver.find_element_by_xpath("//input[@name='expire_date']")
        self.owner_input = self.driver.find_element_by_xpath("//input[@name='uid']")
        self.add_button = self.driver.find_element_by_xpath("//*[@id='root']/div/div[3]/div[2]/div/div[3]/div/div/div/div/div[3]/button[1]")

    @staticmethod
    def get_expire_time():
        now = datetime.now()
        aDay = timedelta(days=7)
        now = now + aDay
        return now.strftime('%m/%d/%Y')

class ChangeStatusPage:
    def __init__(self):
        pass