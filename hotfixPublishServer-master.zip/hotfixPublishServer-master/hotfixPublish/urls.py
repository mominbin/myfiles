from django.conf.urls import url
 
from . import view
 
urlpatterns = [
    url(r'^publish$', view.publish),
    url(r'^index', view.index),
    url(r'^doDownload', view.do_download),
    url(r'^getDownloadProgress',view.download_progress),
    url(r'^doUpload', view.do_upload),
    url(r'^getUploadProgress',view.upload_progress),
    url(r'^uploaded_check',view.uploaded_check),
]