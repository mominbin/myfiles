from clazz.crawler.phare import phare
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import os
import configparser
from os import listdir
from os.path import isfile, join
from hotfixPublish.settings import CONF_DIR


class HotFixTools:
    driver = None
    cf = None
    MAIN_PAGE = 1
    LOGIN_PAGE = 2

    message = {}

    def __init__(self, driver, index):
        self.read_config()
        self.message = self.get_phare_message(index)
        # FileHandle(self.message["info"]).readme_download()
        self.driver = driver

    def main(self, page):
        self.driver.get(page)
        self.process_login_page()
        self.wait(20, "//form[@name='addForm']/input")
        self.add_new_hot_fix()
        self.type_in()
        self.click_save()
        self.wait(20, '//*[@id="file1"]')
        self.upload_readme_files()
        self.add_hotfix_files()
        self.click_done()
        self.available_to_yes()
        # self.publish()

    def read_config(self):
        os.chdir(os.getcwd())
        cf = configparser.ConfigParser()
        self.cf = cf
        self.cf.read(CONF_DIR)

    def is_login_page(self):
        username_input = self.driver.find_elements_by_xpath('//*[@id="username"]')[0]
        return username_input.is_displayed()
        # return EC.presence_of_element_located((By.XPATH, "//*[@id='password']"))

    def is_main_page(self):
        try:
            self.driver.find_elements_by_xpath("//form[@name='addForm']/input")[0]
            return True
        except Exception as e:
            print(e)
            return False

    def wait_next_page(self, seconds):
        try:
            WebDriverWait(self.driver, seconds).until(
                EC.presence_of_element_located((By.XPATH, "//*[@id='password']")) or EC.presence_of_element_located(
                    (By.XPATH, "//form[@name='addForm']/input")))
        finally:
            if self.is_main_page():
                current_page = self.MAIN_PAGE
            elif self.is_login_page():
                current_page = self.LOGIN_PAGE
            return current_page

    def input_account_info(self, username, password):
        username_input = self.driver.find_elements_by_xpath('//*[@id="username"]')[0]
        password_input = self.driver.find_elements_by_xpath('//*[@id="password"]')[0]
        username_input.send_keys(username)
        password_input.send_keys(password)

    def process_login_page(self):
        username = self.cf.get("account", "ssl_account")
        password = self.cf.get("account", "ssl_password")
        current_pge = self.wait_next_page(20)
        if current_pge == self.LOGIN_PAGE:
            self.input_account_info(username, password)
            self.driver.find_elements_by_xpath("//*/input[@type='submit']")[0].click()

    def modify_step(self, page):
        self.driver.get(page)
        self.wait(20, "//input[@type='submit' and @value='Modify']")
        self.enter_detail()
        self.click_modify()
        self.click_modify_of_upload_file()
        self.upload_readme_files()
        self.add_hotfix_files()
        self.click_done()

    def type_in(self):
        elements = {
            "prodVer": Select(self.driver.find_elements_by_xpath('//select[@name="prodVer"]')[0]),
            "avail": Select(self.driver.find_elements_by_xpath('//select[@name="avail"]')[0]),
            "status": Select(self.driver.find_elements_by_xpath('//select[@name="status"]')[0]),
            "expire": self.driver.find_elements_by_xpath('//input[@name="expire"]')[0],
            "pdate": self.driver.find_elements_by_xpath('//input[@name="pdate"]')[0],
            "defectId": self.driver.find_elements_by_xpath('//input[@name="defectId"]')[0],
            "ownerSEA": self.driver.find_elements_by_xpath('//input[@name="ownerSEA"]')[0],
            "patchId": self.driver.find_elements_by_xpath('//input[@name="patchId"]')[0],
            "oneLiner": self.driver.find_elements_by_xpath('//input[@name="oneLiner"]')[0]
        }
        message = self.message
        owner_email = self.cf.get("patch_central", "owner_email")
        
        elements["prodVer"].select_by_index(
            self.get_version_index(elements["prodVer"], message["version"], message['info']['patch']))
        # set status to  "HOTFIX  -  SW hotfix"
        elements["status"].select_by_index(8)
        # set Available field to no before published.
        elements["avail"].select_by_index(1)
        elements["ownerSEA"].clear()
        elements["ownerSEA"].send_keys(owner_email)
        elements["defectId"].clear()
        elements["defectId"].send_keys(message["defectId"])
        elements["patchId"].clear()
        elements["patchId"].send_keys(message["patchId"])
        elements["oneLiner"].clear()
        elements["oneLiner"].send_keys(message["patchId"])

    def click_save(self):
        self.driver.find_elements_by_xpath("//input[@name='unpublished' and @value='save']")[0].click()

    def wait(self, seconds, element_xpath):
        try:
            element = WebDriverWait(self.driver, seconds).until(
                EC.presence_of_element_located((By.XPATH, element_xpath))
            )
        finally:
            pass

    def get_version_index(self, select, version, patch):
        for i, option in enumerate(select.options):
            if(version=='9.52'):
                print(version+'p'+patch)
                if option.text.replace(version+'p'+patch, "").strip() == "sm":
                    return i
            elif option.text.replace(version, "").strip() == "sm":
                return i
        return -1

    def get_file_index(self, selection, name):
        for i, option in enumerate(selection.options):
            if option.text == name:
                return i
        return -1

    def add_new_hot_fix(self):
        self.driver.find_elements_by_xpath(
            "//form[@name='addForm']/input")[1].click()

    def click_modify(self):
        self.driver.find_elements_by_xpath(
            "//input[@type='submit' and @value='Modify']")[0].click()

    def click_modify_of_upload_file(self):
        self.driver.find_elements_by_xpath('//label[contains(text(), "Uploaded Files")]/../../td[2]/a')[0].click()

    def upload_readme_files(self):
        upload_path = self.cf.get("patch_central", "upload_path")
        files = [f for f in listdir(upload_path) if isfile(join(upload_path, f))]
        self.driver.find_element_by_id("file1").send_keys(upload_path+"\\"+files[0])
        if len(files) > 1:
            self.driver.find_element_by_id("file2").send_keys(upload_path+"\\"+files[1])
        self.click_add()

    def click_add(self):
        self.driver.find_elements_by_xpath("//input[@type='button' and @value='Add']")[0].click()

    def add_hotfix_files(self):
        select = Select(self.driver.find_elements_by_xpath('//select[@name="binFileName"]')[0])
        md5 = self.message["md5"]
        for key in md5:
            select.select_by_index(self.get_file_index(select, key))
            self.fill_md5(md5[key])
            self.click_add()
            self.wait_add_file_done(key)

    def wait_add_file_done(self, file_name):
        file_in_table_xpath = ""
        self.wait(20,file_in_table_xpath)
        pass


    def fill_md5(self,value):
        self.driver.find_element_by_id("mdFiveVal").send_keys(value)

    def click_done(self):
        self.driver.find_elements_by_xpath("//input[@type='button' and @value='Done']")[0].click()

    # TODO
    def enter_detail(self):
        self.driver.get()

    def get_phare_message(self, index):
        """get the input information from phare"""
        return phare.get_message(index)

    def available_to_yes(self):
        available = Select(self.driver.find_elements_by_xpath('//select[@name="avail"]')[0])
        available.select_by_index(1)

    def publish(self):
        self.driver.find_elements_by_xpath('//input[@name="published" and @value="publish"]')[0].click()
