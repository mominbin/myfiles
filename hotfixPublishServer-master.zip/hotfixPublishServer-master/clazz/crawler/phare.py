from pyquery import PyQuery
import time
import requests
import configparser
import re
from hotfixPublish.settings import CONF_DIR
import copy


class PhareMessage:

    PHARE = "http://smreport.hpeswlab.net/Hotfix/Main.cshtml"
    LOGIN = "http://smreport.hpeswlab.net/Account/Login"
    usr_agent = {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
        'Accept-Encoding': 'none',
        'Accept-Language': 'en-US,en;q=0.8',
        'Connection': 'keep-alive'
    }
    main_page_saw = None
    PRODUCT_TYPE = "SM"
    VERSION = ""
    PATCH_NO = "0"
    BUILD_NO = ""
    HOTFIX_NO=""
    releasingTD = None
    cf = None
    is_src = False

    def __init__(self):
        self.cf = self.get_cf()
        self.main_page_saw = self.get_main_page_saw(self.LOGIN, self.usr_agent, self.get_account(), self.PHARE)
        self.release_info_list = []
        self.update_release_info_list()

    @staticmethod
    def get_cf():
        cf = configparser.ConfigParser()
        cf.read(CONF_DIR)
        return cf

    @staticmethod
    def get_main_page_saw(login_url, agent, login_info, after_url):
        s = requests.session()
        pj = PyQuery(s.get(login_url, headers=agent).text)
        token = pj("input[name='__RequestVerificationToken']")
        login_info["__RequestVerificationToken"] = token[0].get("value")
        login = s.post(login_url, data=login_info, headers=agent)
        r = s.get(after_url, cookies=login.cookies, headers=agent)
        saw = r.content
        return saw

    @staticmethod
    def get_saw(url, agent):
        return requests.get(url, headers=agent).content

    def get_account(self):
        email = self.cf.get("account","email")
        password = self.cf.get("account","password")
        data = {"email": email, "password": password}
        return data

    def get_message(self, index):
        self.releasingTD = self.get_owners_td(self.main_page_saw, index)
        info = self.get_hotfix_name()
        defectId = self.get_cr_id(self.get_saw(self.get_cr_list_url(), self.usr_agent))
        data = {
            "type": self.PRODUCT_TYPE,
            "version": self.VERSION,
            "patch": self.PATCH_NO,
            "hotfix_no": self.HOTFIX_NO,
            "build_no": self.BUILD_NO
        }

        file_list_temp = self.get_release_info_list()
        file_list = []
        for url in file_list_temp[index-1]["file_urls"]:
            if url != '':
                name = url[url.rfind("/")+1:]
                file_list.append(name)

        input_info = {
            "defectId": defectId,
            "patchId": info["name"],
            "version": self.VERSION,
            "md5":info["md5"],
            "info":data,
            "file_list":file_list
        }
        return input_info

    def get_release_files_name(self, index):
        ril = copy.deepcopy(self.release_info_list)
        urls = ril[index]["file_urls"]
        for i in range(len(urls)):
            url = urls[i]
            urls[i] = url[url.rfind("/")+1:]
        return urls

    def update_saw(self):
        self.main_page_saw = self.get_main_page_saw(self.LOGIN, self.usr_agent, self.get_account(), self.PHARE)

    def update_release_info_list(self):
        self.update_saw()
        pj = PyQuery(self.main_page_saw)
        trs = pj('div#tabs-1 table.htmlTableList tbody tr')
        release_info_list = []
        for i in range(len(trs)):
            release_info_list.append(self.get_release_info(trs, i))
        self.release_info_list = release_info_list

    def get_release_info_list(self):
        return self.release_info_list

    def get_release_info(self, trs, i):
        tds = trs[i].findall("td")
        has_build = False
        build_page = tds[15].getchildren()[0].get("href")
        build_no = tds[15].getchildren()[0].text
        if build_no:
            has_build = True
        if has_build and build_page.lower().find('src') < 0:
            file_urls = self.get_file_urls(build_page)
        else:
            file_urls = ""
        release_info = {
            "release_name": tds[0].text,
            "owner": tds[22].text,
            "index": i+1,
            "has_build": has_build,
            "file_urls": file_urls
        }
        return release_info

    def get_file_urls(self, url):
        pj = PyQuery(self.get_saw(url, self.usr_agent))
        trs = pj('tr')
        download_urls = []
        for i in range(3, len(trs)-1):
            download_url = url + "/" + pj('tr')[i].find("td/a").get("href")
            if download_url.find("md5sum") > -1 or download_url.find(".properties") > -1:
                continue
            download_urls.append(download_url)
        return download_urls

    @staticmethod
    def get_owners_td(doc, index=0):
        pj = PyQuery(doc)
        tr_list = pj('div#tabs-1 table.htmlTableList tbody tr')

        if index != 0:
            return tr_list[index-1].findall("td")
        # name = ""
        # if self.cf.has_option("account", "owner"):
        #     name = self.cf.get("account", "owner")
        # else:
        #     name = pj("div#topbar ul li")[0].text[9:]
        # for tr in tr_list:
        #     td_list = tr.findall("td")
        #     if td_list[len(tr) - 2].text.lower().strip() == name.lower():
        #         return td_list

    def get_build_no(self):
        build_no = self.releasingTD[15].getchildren()[0].text
        if None != build_no:
            self.BUILD_NO = build_no
        if self.cf.has_option("other", "md5_url"):
            url = self.cf.get("other", "md5_url")
            str = url.replace("-", "").replace("_", "").lower()
            pattern = re.compile(r'build\d+')
            self.BUILD_NO = pattern.search(str).group()[5:];

    def get_release_name(self):
        release_name = self.releasingTD[0].text.strip().replace(" ","")
        return release_name.lower()

    def parse_release_name(self):
        release_name = self.get_release_name()
        if (release_name.find("src") > -1):
            self.PRODUCT_TYPE = "SRC"
            release_name = release_name.replace("src", "")
        elif (release_name.find("suite") > -1):
            self.PRODUCT_TYPE = "SUITE"
            release_name = release_name.replace("suite", "")
        pattern = re.compile(r'[A-Za-z]+\d+\.*\d*')
        match = pattern.findall(release_name)
        for item in match:
            if item.find("sm")>-1:
                self.VERSION = item[2:]
            elif item.find("p")>-1:
                self.PATCH_NO = item.replace(".", "")[1:]
            elif item.find("hf") > -1:
                self.HOTFIX_NO = item[2:]

    def get_hotfix_name(self):
        hf_files_md5 = ""
        if self.cf.has_option("other", "md5_url"):
            url = self.cf.get("other", "md5_url")
        else:
            url = self.releasingTD[15].getchildren()[0].get("href")
        if url is not None:
            hf_files_md5 = ""
            # hf_files_md5 = self.get_hotfix_files_md5(url)  md5 no more needed.
        self.parse_release_name()
        self.get_build_no()
        name = self.PRODUCT_TYPE + self.VERSION
        if self.BUILD_NO != "":
            name += "." + self.BUILD_NO
        if self.PATCH_NO != "0":
            name += "_P" + self.PATCH_NO
        name += "_HF" + self.HOTFIX_NO
        return {"name":name,  "md5": hf_files_md5}

    def get_cr_list_url(self):
        el = self.releasingTD[14].getchildren()[0]
        return 'http://smreport.hpeswlab.net/Hotfix/Detail.cshtml/' + el.get("id") + '/' + str(time.time())

    def get_hotfix_files_md5(self,url):
        pj = PyQuery(self.get_saw(url, self.usr_agent))
        md5_url = url + "/" + pj('tr')[3].find("td/a").get("href")
        pj_next = PyQuery(self.get_saw(md5_url, self.usr_agent))
        hf_files_md5_str = pj_next("p").text()
        str_list = hf_files_md5_str.split(" ")
        hf_files_md5 = {}
        keys = []
        values = []
        for item in str_list:
            if item.find("*") > -1:
                keys.append(item[1:])
            else:
                values.append(item)
        for i, key in enumerate(keys):
            hf_files_md5[key] = values[i]
        return hf_files_md5

    def get_cr_id(self, doc):
        pj = PyQuery(doc)
        tr_list = pj('tbody tr')
        qc_id_str = ""
        for tr in tr_list:
            qc_id_str += tr.findall("td")[1].text.strip() + " "
        return qc_id_str


phare = PhareMessage()

