from django.http import HttpResponse
from django.shortcuts import render
from clazz.crawler.phare import phare
import json
from clazz.fileSingleton import fileSingleton
from clazz.downloadTasks import DownloadThread
from clazz.downloadTasks import UploadThread
from clazz.services.publish import PublishStep
from fileHandle import FileHandle
from clazz.tools.checker import Checker
 # Usage
 # cd path to you manage.py file path.
#  python manage.py runserver 0.0.0.0:8000
# replace the ip to you pc ip address.
# http://10.5.41.45:8000/publish?index=5


def publish(request):
    if 'index' in request.GET:
        index = request.GET['index']
        # print('success recived the index number!number = ' + index)
        # main_page = "https://patch-central.corp.hpecorp.net/crypt-web/protected/viewProduct.do?productid=crypt:service_manager:"
        # tool = HotFixTools(webdriver.Firefox(), int(index))
        # tool.main(main_page)

        print(''' =========== get the message from PHARE =========== ''')
        message = phare.get_message(int(index))
        print(''' =========== download the readme file to the temple folder ===========''')
        # FileHandle(message["info"]).readme_download()
        print(''' =========== download the readme file to the temple folder ===========''')
        ps = PublishStep(message)
        ps.main()
        return HttpResponse("success recived the index number! " + index)


def uploaded_check(request):
    i = int(request.GET['index']) - 1
    return HttpResponse(json.dumps(Checker.preparation_check(i)), content_type="application/json")


def index(request):
    context = {}
    context['version'] = "0.1beta"
    # phare.update_release_info_list()
    release_list = phare.get_release_info_list()
    release_json = json.dumps(release_list)
    context['release_list'] = release_list
    context['release_json'] = release_json
    return render(request, 'index.html', context)


def do_download(request):
    url = request.GET['url']
    down_key = "down_" + url
    if down_key not in fileSingleton.get_downloaders():
        dt = DownloadThread(url)
        dt.start()
    return HttpResponse(json.dumps({"result":"success"}), content_type="application/json")


def download_progress(request):
    url = request.GET['url']
    down_key = "down_" + url
    downloader = fileSingleton.get_downloader(down_key)
    return HttpResponse(json.dumps(downloader), content_type="application/json")


def do_upload(request):
    url = request.GET['url']
    up_key = "up_" + url
    if up_key not in fileSingleton.get_uploaders():
        ut = UploadThread(url)
        ut.start()
    return HttpResponse(json.dumps({"result": "success"}), content_type="application/json")


def upload_progress(request):
    url = request.GET['url']
    up_key = "up_" + url
    uploader = {"done": False, "percent": 0}
    uploaders = fileSingleton.get_uploaders()
    if up_key in uploaders:
        uploader = fileSingleton.get_uploader(up_key)
    return HttpResponse(json.dumps(uploader), content_type="application/json")