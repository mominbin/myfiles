from django.test import TestCase
from selenium import webdriver
from clazz.services.pageBeans import *
import time
from selenium.webdriver.common.keys import Keys
from clazz.tools.locateUtils import *
from pyquery import PyQuery


class PageBeansTest(TestCase):
    def setUp(self):
        self.driver = webdriver.Firefox()
        self.url = "https://rdapps.swinfra.net/hotfix/#/hotfixList/34/143"

    def test_get_html(self):
        self.driver.get(self.url)
        WebDriverWait(self.driver, 10).until(EC.alert_is_present())
        alert = self.driver.switch_to.alert
        alert.send_keys("mmo@microfocus.com" + Keys.TAB + "Taurus.m1")
        time.sleep(1)
        self.driver.switch_to.alert.accept()

        # self.driver.implicitly_wait(30)
        sm_page = SMMainPage(self.driver, "sm9.61")
        sm_page.target_item.click()
        sm_page.add_button.click()
        # time.sleep(10)
        # handles = self.driver.window_handles
        # self.driver.switch_to.active_element
        html = self.driver.page_source
        print(html)
        root = LocateUtils.get_html_dom(html)

    def _test_read_file(self):
        file_object = open("sm_page_in_hotfix_list_mock")
        file_context = ''
        try:
            file_context = file_object.read()
        finally:
            file_object.close()
        doc = PyQuery(file_context)
        LIs  = doc('ul li')
        for li in LIs:
            text = PyQuery(li).text()
            if text.lower().replace(" ", "") == 'sm9.61':
                print("origin text is: " + text)
                return

    def _test_jquery_execution(self):
        url = "http://localhost:8080/test/test.html"
        driver = webdriver.Firefox()
        driver.get(url)
        sm_page = SMMainPage(driver, "sm9.61")
        sm_page.target_item.click()
        sm_page.add_button.click()