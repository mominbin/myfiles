import os
import configparser
import urllib.request
from pyquery import PyQuery
import requests
import re
import zipfile
from os import listdir
from os.path import isfile, join
from hotfixPublish.settings import CONF_DIR


class FileHandle:
    user_agent = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
        'Accept-Encoding': 'none',
        'Accept-Language': 'en-US,en;q=0.8',
        'Connection': 'keep-alive',
        'Authorization': 'Basic bW9taW5iOlBpc2Nlcy5tMg=='
    }
    user_agent_swinfra = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
        'Accept-Encoding': 'none',
        'Accept-Language': 'en-US,en;q=0.8',
        'Connection': 'keep-alive',
        'Authorization': 'Basic bW9taW5iOlBpc2Nlcy5tMg==',
        'Host': 'svswsvn001g.swinfra.net'
    }
    # DOMAIN_SVN = "https://csvnaus1-pro.austin.hpecorp.net:18580/svn/itsm-sm/ServiceManager/branches"
    # DOMAIN_SRC = "https://csvnaus1-pro.austin.hpecorp.net:18580/svn/itsm-src/branches/src-"
    # DOMAIN_GIT = "https://github.houston.softwaregrp.net/SM/doc/tree"
    # DOMAIN_GIT_REAL = "https://raw.github.houston.softwaregrp.net/SM/doc"
    readme_download_path = ""
    cf = None
    data = {}
    url_from_git = False
    url_from_svn = False

    def __init__(self, data):
        self.read_config()
        self.data = data
        self.DOMAIN_SVN = self.cf.get("domain", "domain_svn")
        self.DOMAIN_SRC = self.cf.get("domain", "domain_src")
        self.DOMAIN_GIT = self.cf.get("domain", "domain_git")
        self.DOMAIN_GIT_REAL = self.cf.get("domain", "domain_git_real")
        version_no = data["version"]
        small_version = version_no[2:3]
        version_parent = version_no[:len(version_no) - 1] + "x"
        middle_path = version_no
        if data["patch"] != "0":
            middle_path += "p" + data["patch"]
        if data["type"] == "SRC":
            self.readme_download_path = self.DOMAIN_SRC + middle_path + "-release/catalog-doc/readme_files/"
        elif data["type"] == "SM":
            if small_version == "3" or small_version == "4":
                self.readme_download_path = self.DOMAIN_SVN + "/" + version_parent + "/" + middle_path +\
                                            "/doc/readme_files/"
            elif int(small_version) >= 5:
                self.readme_download_path = self.DOMAIN_GIT + "/" + version_parent + "/" + middle_path +\
                                            "/readme_files/"

    def read_config(self):
        cf = configparser.ConfigParser()
        cf.read(CONF_DIR)
        self.cf = cf

    @staticmethod
    def get_saw(url, agent, verify=True):
        print("url: " + url)
        print("agent: " + str(agent))
        # content = requests.get(url, auth=('mominb', 'Pisces.m2'), headers=agent)
        # return content
        return requests.get(url, headers=agent, verify=verify).content

    def get_readme_list(self):
        url = self.readme_download_path
        self.url_from_git = url.find("git") > -1
        self.url_from_svn = url.find("svn") > -1
        a_list = []
        a_list_temp = None
        if self.url_from_svn:
            pj = PyQuery(self.get_saw(url, self.user_agent, False))
            a_list_temp = pj("index file")
            for f in a_list_temp:
                a_list.append(f.get("href"))
        elif self.url_from_git:
            pj = PyQuery(self.get_saw(url, self.user_agent, False))
            a_list_temp = pj("table td[class='content'] span a")
            for f in a_list_temp:
                a_list.append(f.text)
        return self.pick_to_download(a_list)

    def pick_to_download(self, a_list):
        pattern_str = ""
        if self.data["patch"] == "0":
            pattern_str = "sm" + self.data["version"].replace(".","\.") + "\.\d{4}hf\d{1,2}readme\.txt"
        else:
            pattern_str = "sm" + self.data["version"].replace(".","\.") + "\.\d{4}p\d{1,2}hf\d{1,2}readme\.txt"
        pattern = re.compile(pattern_str)
        download_list = []
        for a in a_list:
            text = a.lower()
            text = text.replace("_", "")
            text = text.replace("-", "")
            match = pattern.search(text)
            if match:
                download_list.append(a)
        return download_list

    def print_url(self):
        print(self.readme_download_path)

    @staticmethod
    def get_hotfix_no(string):
        pattern = re.compile("hf\d{1,2}")
        match = pattern.search(string.lower())
        if match:
            return match.group()[2:]
        else:
            return ""

    def remove_readme_file(self):
        upload_path = self.cf.get("patch_central", "upload_path")
        files = [f for f in listdir(upload_path) if isfile(join(upload_path, f))]
        for file in files:
            file_name = os.path.basename(file)
            if file_name.find('readme') > -1:
                os.remove(upload_path + "\\" + file)

    def download(self, name):
        # if a readme file is stored in git , then replacement processing, others will not.
        # git_real_download_path_parent = "https://raw.github.houston.softwaregrp.net/SM/doc/9.5x/9.52p2/readme_files/"
        git_real_download_path_parent = self.readme_download_path.replace(self.DOMAIN_GIT, self.DOMAIN_GIT_REAL)
        url = git_real_download_path_parent + name
        print(url)
        save_path = self.cf.get("patch_central", "upload_path") + "\\" + name
        print("downloading with urllib")
        print(save_path)
        urllib.request.urlretrieve(url, save_path)

    def download_file(self, name):
        url = self.readme_download_path + name
        file = self.cf.get("patch_central", "upload_path") + "\\" + name
        # download file from svn
        if self.url_from_svn:
            r = requests.get(url, headers = self.user_agent, verify=False)
            with open(file, 'wb') as f:
                f.write(r.content)
        # download file from git
        if self.url_from_git:
            url = url.replace(self.DOMAIN_GIT, self.DOMAIN_GIT_REAL)
            urllib.request.urlretrieve(url, file)
        return file

    def zip_file(self, file):
        save_path = self.cf.get("patch_central", "upload_path") + "\\"
        zip_file = zipfile.ZipFile(save_path + "readme_files.zip" , 'a')
        zip_file.write(save_path + file, file, compress_type=zipfile.ZIP_LZMA)
        zip_file.close()

    def readme_download(self):
        self.remove_readme_file()
        list = self.get_readme_list()
        hotfix_no = self.data["hotfix_no"]
        for a in list:
            if hotfix_no != self.get_hotfix_no(a):
                file = self.download_file(a)
                self.zip_file(a)
                os.remove(file)
            else:
                self.download_file(a)


