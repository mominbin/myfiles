# unit test example
from test.unitestSample_wedget import Widget
import unittest


# 执行测试的类
class WidgetTestCase(unittest.TestCase):
    def setUp(self):
        self.widget = Widget()

    def tearDown(self):
        self.widget.dispose()
        self.widget = None

    def testSize(self):
        self.assertEqual(self.widget.getSize(), (40, 40))

    def testResize(self):
        self.widget.resize(100, 100)
        self.assertEqual(self.widget.getSize(), (100, 100))
    # 测试


class WidgetTestSuite(unittest.TestSuite):
    def __init__(self):
        unittest.TestSuite.__init__(self, map(WidgetTestCase,("testSize", "testResize")))



# 构造测试集
def suite():
    # suite = unittest.TestSuite()
    # suite.addTest(WidgetTestCase("testSize"))
    # suite.addTest(WidgetTestCase("testResize"))
    # return suite

    # or
    return WidgetTestSuite()

    # or if you name test case prefix by "test"  then you can return
    # unittest.makeSuite(WidgetTestCase, "test")


if __name__ == "__main__":
    runner = unittest.TextTestRunner()
    runner.run(suite)

    # unittest.main() or unittest.main(defaultTest = 'suite')