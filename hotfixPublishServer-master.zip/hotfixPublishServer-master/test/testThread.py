import threading
import time
from clazz.tools.fileUtils import Download
from clazz.fileSingleton import fileSingleton
from clazz.downloadTasks import UploadThread


class DownloadThread (threading.Thread):
    def __init__(self, url):
        threading.Thread.__init__(self)
        fileSingleton.set_downloader("down_" + url, {})
        self.url = url

    def run(self):
        print ("开始线程：Download " + self.url)
        Download.download_with_schedule(self.url)
        print ("退出线程：Download " + self.url)


class GetPercentThread (threading.Thread):
    def __init__(self, url):
        threading.Thread.__init__(self)
        self.url = url

    def run(self):
        while url not in fileSingleton.get_downloaders():
            time.sleep(1)

        downloader = fileSingleton.get_downloader(self.url)
        done = downloader["done"]

        while done is not True:
            downloader = fileSingleton.get_downloader(self.url)
            done = downloader["done"]
            time.sleep(1)
            print(downloader["percent"])





def request(url):
    downloader = {}
    if "down_"+url not in fileSingleton.get_downloaders():
        dt = DownloadThread(url)
        dt.start()
    else:
        downloader = fileSingleton.get_downloader("down_"+url)

    return downloader

def test_donwload(url):

    dler= {}


    isDnoe = False
    while isDnoe is not True:
        time.sleep(1)
        dler = request(url)
        if "done" in dler:
            isDnoe = dler["done"]
            print(dler["percent"])


def test_upload(url):
    up_key = "up_" + url
    if up_key not in fileSingleton.get_uploaders():
        ut = UploadThread(url)
        ut.start()
    isDnoe = False

    while isDnoe is not True:
        time.sleep(1)
        uploaders = fileSingleton.get_uploaders()
        if up_key in uploaders:
            uploader = fileSingleton.get_uploader(up_key)
            if "done" in uploader:
                isDnoe = uploader["done"]
                print(uploader["percent"])

url = "http://servicemanager.svs.hpeswlab.net/jenkins/9.4x_Releases/9.41/9.41_Patch1_HF4-Release-Build-1025_MA/sm9.41.1025-P1HF4_Web_Tier.zip"
test_upload(url)