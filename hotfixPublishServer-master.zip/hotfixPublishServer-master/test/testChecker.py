from clazz.tools.checker import Checker
import json
import time


def test_get_list():
    file = (Checker.get_list_from_FTP())
    print(file)


def test_has_file():
    print(Checker.has_file("ServicePortal_Installer.zip"))


def test_short_file_check():
    list = ['ServicePortal_Installer.zip', 'sm9.52.3017-P3-HF5_Windows_Client.zip','linux-x86_unify.tar.Z']
    short_list = Checker.short_file_check(list)
    if len(short_list) == 0:
        print("uploaded all!")
    else:
        print("please upload file(s) as below:")
        for file in short_list:
            print(file)

# test_short_file_check()
# test_get_list()
