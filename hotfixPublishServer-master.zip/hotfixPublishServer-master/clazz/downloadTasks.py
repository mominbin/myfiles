import threading
from clazz.tools.fileUtils import Download
from clazz.tools.fileUtils import FTPUpload
from clazz.fileSingleton import fileSingleton


class DownloadThread (threading.Thread):
    started = False
    ended = False

    def __init__(self, url):
        threading.Thread.__init__(self)
        fileSingleton.set_downloader("down_" + url, {})
        self.url = url

    def run(self):
        print("开始线程：Download " + self.url)
        self.started = True
        self.ended = True
        Download.download_with_schedule(self.url)
        self.started = False
        self.ended = False
        print("退出线程：Download " + self.url)


class UploadThread (threading.Thread):
    started = False
    ended = False

    def __init__(self, url):
        threading.Thread.__init__(self)
        fileSingleton.set_downloader("up_" + url, {})
        self.url = url

    def run(self):
        print("开始线程：Upload " + self.url)
        self.started = True
        self.ended = True
        FTPUpload.ftp_upload(self.url)
        self.started = False
        self.ended = False
        print("退出线程：upload " + self.url)