from clazz.tools.fileUtils import *


class TestFileUtils:
    @staticmethod
    def test_list_ftp_server_files():
        print(FTPUpload.is_exist('sm9.61.0048-HF3_Web_Tier.zip'))


TestFileUtils.test_list_ftp_server_files()