from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import configparser
from os import listdir
from os.path import isfile, join
from hotfixPublish.settings import CONF_DIR
from hotfixPublish.settings import PROXY_ZIP
import time
from selenium.webdriver.common.keys import Keys
from .pageBeans import *


class PublishUtils:

    @staticmethod
    def get_cf():
        cf = configparser.ConfigParser()
        cf.read(CONF_DIR)
        return cf

    @staticmethod
    def get_driver(browser, load_cache=False):
        driver = None
        if browser == "Chrome":
            chrome_profile_dir = r"C:\Users\mominb\AppData\Local\Google\Chrome\User Data\Default"
            options = webdriver.ChromeOptions()
            ''' 因为页面需要认证，认证弹出来的窗口无法使用selenium 本身来处理， 网上给出来的一个方法就是使用chrome本身的插件去
                处理， PROXY_ZIP就是这个插件。 目前使用这个插件也没法正常进入页面...'''
            options.add_extension(PROXY_ZIP)
            # options.add_argument("--user-data-dir=" + os.path.abspath(chrome_profile_dir))
            driver = webdriver.Chrome(chrome_options=options) if load_cache else webdriver.Chrome()
        elif browser == "Firefox":
            fp = webdriver.FirefoxProfile(r'C:\Users\mominb\AppData\Roaming\Mozilla\Firefox\Profiles\9e8li553.default')
            # fo = webdriver.FirefoxOptions()
            # fo.set_preference("network.automatic-ntlm-auth.trusted-uris", "rdapps.swinfra.net")
            driver = webdriver.Firefox(fp) if load_cache else webdriver.Firefox()
        return driver

    @staticmethod
    def parse_release_version(message):
        ver_no = message['info']['version']
        version = ""
        if float(ver_no) >= 9.52:
            version = "sm" + ver_no if message['info']['patch'] is '0' else "sm" + ver_no + "p" + message['info']['patch']
        else:
            version = "sm" + ver_no
        return version

    @staticmethod
    def wait_present(driver, xpath):
        try:
            wait = WebDriverWait(driver, 15)
            return wait.until(EC.presence_of_element_located((By.XPATH, xpath)))
        except Exception as e:
            print(str(e))

    @staticmethod
    def get_xpath(element):
        return element.getroottree().getpath(element)

    @staticmethod
    def get_status_option_xpath(html, status):
        print("get_status_option_xpath: " + status)
        html = etree.HTML(html)
        option = html.xpath("//div[div='" + status + "']")[0]
        return PublishUtils.get_xpath(option)

    @staticmethod
    def get_update_popup_page_button_xpath(html, button_name):
        html = etree.HTML(html)
        option = html.xpath("//button[div='" + button_name + "']")[0]
        return PublishUtils.get_xpath(option)

    @staticmethod
    def get_xpath_by_file_name(html, file_name):
        html = etree.HTML(html)
        checkbox = html.xpath("//td[font='" + file_name + "']")[0].getparent().xpath(".//div[@class='hpe-checkbox']")[0]
        return PublishUtils.get_xpath(checkbox)


class PublishStep:
    def __init__(self, message):
        self.cf = PublishUtils.get_cf()
        self.url = self.cf.get("patch_central", "publish_site")
        self.readme_path = self.cf.get("patch_central", "upload_path")
        self.driver = None
        self.message = message

    def set_driver(self, driver):
        self.driver = driver

    def main(self):
        self.set_driver(PublishUtils.get_driver('Firefox', False))
        self.login()
        self.add_hot_fix()
        self.input_data()
        self.upload_files()
        # self.change_status()

    def modify(self, url_to_be_modify):
        self.driver.get(url_to_be_modify)
        self.upload_files()
        self.change_status()

    def login(self):
        self.driver.get("https://"+self.url)
        self.login_authentication()

    def add_hot_fix(self):
        sm_page = SMMainPage(self.driver, self.message)
        sm_page.target_item.click()
        sm_page.add_button.click()

    def login_authentication(self):
        WebDriverWait(self.driver, 10).until(EC.alert_is_present())
        self.driver.switch_to.alert.send_keys("mmo@microfocus.com" + Keys.TAB + "Taurus.m1")
        time.sleep(1)
        self.driver.switch_to.alert.accept()

    def wait_add_hotfix_button(self):
        return PublishUtils.wait_present(self.driver, "//*[@title='Add Hotfix']")

    def wait_name_button(self):
        return PublishUtils.wait_present(self.driver, "/html/body/div/div/div[3]/div[2]/div/div[3]/div/div/div/div/div[2]/div/div/table/tbody/tr[1]/td[2]/input")

    def wait_upload_button(self):
        return PublishUtils.wait_present(self.driver, "//*[@title='Upload File']")

    def wait_update_button(self):
        return PublishUtils.wait_present(self.driver, "//*[@title='Update Hotfix']")

    def wait_status_select(self):
        return PublishUtils.wait_present(self.driver, "//div[@name='status']")

    def input_data(self):
        hot_fix_id = self.message['patchId']
        description = "For " + hot_fix_id
        crs = self.message['defectId']
        owner = self.cf.get("patch_central", "owner_email")
        expire_date = HotFixDataPage.get_expire_time()

        hdp = HotFixDataPage(self.driver)
        hdp.hot_fix_id_input.send_keys(hot_fix_id)
        hdp.description_input.send_keys(description)
        hdp.crs_input.send_keys(crs)
        hdp.expire_date_input.send_keys(expire_date)
        hdp.owner_input.clear()
        hdp.owner_input.send_keys(owner)
        hdp.add_button.click()

    def upload_files(self):
        upload_button = self.wait_upload_button()
        upload_button.click()
        self.upload_readme_files()
        upload_button = self.wait_upload_button()
        upload_button.click()
        self.upload_binary_files()

    def upload_readme_files(self):
        upload_button = self.driver.find_element_by_xpath("//*[@type='file']")
        files = self.get_readme_files()
        for file in files:
            real_path = self.readme_path + "\\" + file
            self.add_file(upload_button, real_path)
            time.sleep(1)
        self.driver.find_element_by_xpath("//*[@id='root']/div/div[3]/div[2]/div/div[2]/div/div/div/div/div[3]/button[1]").click()

    def upload_binary_files(self):
        FTP_button = self.driver.find_element_by_xpath("//*[@id='root']/div/div[3]/div[2]/div/div[2]/div/div/div/div/div[3]/button[2]")
        FTP_button.click()
        self.check_binary_files()

    def check_binary_files(self):
        upload_button = PublishUtils.wait_present(self.driver, "//*[@id='root']/div/div[3]/div[2]/div/div[2]/div/div/div/div/div[3]/button[1]")
        files_to_be_check = self.message["file_list"]
        html = self.driver.page_source
        for file_name in files_to_be_check:
            checkbox_xpath = PublishUtils.get_xpath_by_file_name(html, file_name)
            self.driver.find_element_by_xpath(checkbox_xpath).click()
        if len(files_to_be_check) > 0:
            upload_button.click()
        else:
            print("there is no file to upload")
            self.driver.find_element_by_xpath('//*[@id="root"]/div/div[3]/div[2]/div/div[2]/div/div/div/div/div[3]/button[3]').click()

    def change_status(self):
        update_button = self.wait_update_button()
        update_button.click()
        div_select = self.wait_status_select()
        div_select.click()
        time.sleep(1)
        self.driver.find_element_by_xpath("/html/body/div[2]/div/div[2]/div[2]").click()
        time.sleep(1)
        self.driver.find_element_by_xpath('//*[@id="root"]/div/div[3]/div[2]/div/div[2]/div/div/div/div/div[3]/button[1]').click()


    def get_readme_files(self):
        return [f for f in listdir(self.readme_path) if isfile(join(self.readme_path, f))]

    @staticmethod
    def add_file(upload_button, file_real_path):
        upload_button.clear()
        upload_button.send_keys(file_real_path)

