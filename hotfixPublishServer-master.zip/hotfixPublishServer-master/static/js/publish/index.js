window.sleep = function sleep(n) { //n表示的毫秒数
    var start = new Date().getTime();
    while (true) if (new Date().getTime() - start > n) break;
}
window.addListener = function(target, name, fn){
  if (window.addEventListener) {// safari, chrome, firefox
    target.addEventListener(name, fn, false);
  } else { // IE  opera
    target.attachEvent("on"+name, fn);
  }
}

function show_upload_file(index, shortlist){
    var uploadFile = document.getElementById("uploadFile");
    var text = "";

    var header = document.getElementById("uploadHeader");
    header.innerHTML = '';
    uploadFile.innerHTML = '';
    if(index > 0){
        var current = rd[index-1];
        if(current.file_urls != ""){
            text = "Here to select files you need upload to ftp server:";
            createUpload(current.file_urls, shortlist);
        } else {
            text = "There is no available build or hotfix type not supported!";
        }
    } else {
        text ="Please select a valid hotfix!";
    }
    header.innerHTML = text;
}

function uploaded_check(e){
    document.getElementById("uploadFile").innerText = "";
    var pubBtn = document.getElementById("pubBtn");
    var tipsDiv = document.getElementById("tips");
    tipsDiv.innerHTML = "";
    pubBtn.disabled = true;
    var index = $("option:selected", this)[0].index; //get the index of option.
    $.ajax({
        url:"uploaded_check?index=" + index,
        success:function(result){
            var display = "";
            if (result.prepared){
                display = "uploaded files prepared! you can publish hot fix now!"
                pubBtn.disabled = false;
            } else {
                var short_file_list = result.list;
                display = "please upload files(s) as below to the FTP server(ftp://quixy.swinfra.net/patch_upload):"
                for (var i = 0, max = short_file_list.length; i < max; i++){
                    display = display + "<p style='color:red;'>" + short_file_list[i] + "<\p>"
                }
                show_upload_file(index, short_file_list)
            }
            tipsDiv.innerHTML = display;

        }
    });

}

function createUpload(urls, shortList){
    var uploadFile = document.getElementById("uploadFile");
    for(i=0, len = urls.length; i < len; i++){
        // var input = document.createElement('input');
        if(isInShortList(urls[i], shortList)){
            doCreateUploadDom(uploadFile, urls[i], i);
        }
    }
}

function isInShortList(text, shortList){
    isIn = false;
    for (i in shortList){
        if(text.indexOf(shortList[i])>-1){
            isIn = true
            break
        }
    }
    return isIn
}

function doCreateUploadDom(uploadFile, url, i){
    var text = document.createTextNode(url);
    var a = document.createElement("a");
    var uploadBtn = document.createElement("input");
    var progressDiv = document.createElement("div");
    progressDiv.setAttribute("id","forAfile"+i);
    var br = document.createElement("br");
    // input.setAttribute("id","chk"+i)
    // input.setAttribute("type","checkbox");
    // input.setAttribute("value",urls[i]);
    a.appendChild(text);
    a.setAttribute("id", "file"+i);
    // a.setAttribute("onclick","up_to_ftp_server()");
    uploadBtn.setAttribute("id","forAfile"+i);
    uploadBtn.setAttribute("type","button");
    uploadBtn.setAttribute("value","upload");
    uploadBtn.setAttribute("onclick","up_to_ftp_server()")

    uploadFile.appendChild(a);
    uploadFile.appendChild(uploadBtn);
    uploadFile.appendChild(progressDiv);
    uploadFile.appendChild(br);
}

function up_to_ftp_server(){
    var a = event.target.previousSibling;
    var progressEl = $("#forA"+a.id)[0];
    var  url = a.innerHTML;
    window.downloadingFiles = window.downloadingFiles || {};
    window.uploadingFiles = window.uploadingFiles || {};
    download(url, progressEl);
}

function download(url, progressEL){
    //开始下载
    $.ajax({
        async:false,
        url: "doDownload?url="+url,
        success: function(result){
            console.log("begin download!");
        }
    });
    // 请求下载进度值
    var sitv = setInterval(function(){
        if(!downloadingFiles[url]){
            var obj = {};
            obj["done"] = false;
            obj["percent"] = "0%";
            progressEL.innerText = obj["percent"];
            downloadingFiles[url] = obj;
        } else {
            $.ajax({
                async:false,
                url: "getDownloadProgress?url="+url,
                success: function(result){
                    console.log(result);
                    downloadingFiles[url] = result;
                    progressEL.innerText = downloadingFiles[url]["percent"];
                    if(result["done"]){
                        clearInterval(sitv);
                        upload(url,progressEL)
                    }
            }});
        }
    },1000);
}

function upload(url, progressEL){
       // 开始上传
    $.ajax({
        async:false,
        url: "doUpload?url="+url,
        success: function(result){
            console.log("begin upload!");
        }
    });
    //请求上传进度
    var upInterval = setInterval(function(){
        if(!uploadingFiles[url]){
            var obj = {};
            obj["done"] = false;
            obj["percent"] = "0%";
            progressEL.innerText = obj["percent"];
            uploadingFiles[url] = obj;
        } else {
            $.ajax({
                async:false,
                url: "getUploadProgress?url="+url,
                success: function(result){
                    console.log(result);
                    uploadingFiles[url] = result;
                    progressEL.innerText = uploadingFiles[url]["percent"];
                    if(result["done"]){
                        clearInterval(upInterval);
                    }
            }});
        }
    },1000);
}

// addListener(document.getElementById("selectIndex"),"change", show_upload_file);
addListener(document.getElementById("selectIndex"),"change", uploaded_check);