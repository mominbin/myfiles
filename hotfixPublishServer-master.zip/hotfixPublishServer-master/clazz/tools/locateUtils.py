from .customizeDecorator import synchronized
from lxml import etree
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import os


class LocateUtils:
    instance = None
    __jquery = None
    __driver = None

    @synchronized
    def __new__(cls, *args, **kwargs):
        if cls.instance is None:
            module_dir = os.path.dirname(__file__)
            with open(os.path.join(module_dir, 'jquery-1.9.1.min.js'), 'r') as jquery_js:
                cls.__jquery = jquery_js.read()
            cls.instance = object.__new__(cls, *args, **kwargs)
        return cls.instance

    @classmethod
    def set_driver(cls, driver):
        cls.instance.__driver = driver
        return cls.instance

    @classmethod
    def load_jquery(cls):
        cls.instance.__driver.execute_script(cls.instance.__jquery)
        return cls.instance

    @classmethod
    def get_element_by_jquery(cls, js_expression, driver = None):
        if driver is not None:
            cls.instance.__driver = driver
            cls.load_jquery()
        elif cls.instance.__driver is None:
            raise Exception
        return cls.instance.__driver.execute_script(js_expression)

    @classmethod
    def get_html_dom(cls, html):
        return etree.HTML(html)

    @classmethod
    def get_xpath(cls, element):
        return element.getroottree().getpath(element)

    @classmethod
    def get_root(cls, driver):
        return cls.get_html_dom(driver.page_source)

    @classmethod
    def wait_present(cls, driver, xpath):
        try:
            wait = WebDriverWait(driver, 15)
            return wait.until(EC.presence_of_element_located((By.XPATH, xpath)))
        except Exception as e:
            print(str(e))