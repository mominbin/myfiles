class FileSingleton(object):

    downloader = {
        "done": False,
        "percent": "0",
        "total": 0,
        "downloaded": 0,
        "title": "",
        "unit": ""
    }

    downloaders = {}
    uploaders = {}

    def set_uploader(self, key, uploader):
        self.uploaders[key] = uploader

    def get_uploader(self, key):
        return self.uploaders[key]

    def get_uploaders(self):
        return self.uploaders

    def set_downloader(self, key, downloader):
        self.downloaders[key] = downloader

    def get_downloader(self, key):
        return self.downloaders[key]

    def get_downloaders(self):
        return self.downloaders


fileSingleton = FileSingleton()
